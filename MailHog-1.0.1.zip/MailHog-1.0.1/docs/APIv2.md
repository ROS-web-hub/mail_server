MailHog API v2
==============

The v2 API is hopefully less of a mess than v1.

The specification is written in [Swagger 2.0](http://swagger.io/).

See the YAML and JSON specifications in the [APIv2](./APIv2) directory.
